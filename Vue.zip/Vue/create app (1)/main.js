const app = Vue.createApp({
    data: function(){ //can also be data(){} with es6 shorthand
        return{
                product: 'Socks',
                description: 'These socks are blue or green ankle socks!'
        }
    }
})