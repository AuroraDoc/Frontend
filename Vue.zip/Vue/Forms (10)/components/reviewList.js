app.component('review-list', {
    props: {
        reviews: {
            type: Array,
            required: true
    }
},
    template:
    /*html*/
    `<div class="review-container">
        <h3>Reviews:</h3>
        <ul>
            <li v-for="(review, index) in reviews">
                {{ review.name }} rated this {{ review.rating }} stars and recommends: {{review.recommend}}
                <br/>
                "{{ review.review }}" <!--the quotes are for text not js-->
            </li>
        </ul>
    </div>`
})