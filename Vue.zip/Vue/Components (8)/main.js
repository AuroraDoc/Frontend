const app = Vue.createApp({
    data() {
        return {
            cart: 0,
            premium: false,
            details: 'The socks are soft'
        }
    },
    methods: {

    }
})