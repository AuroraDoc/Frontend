app.component(product-details, {
    props: {
        details: {
            type: String,
            required: true
        }
    },
    template:
    /*html*/ 
    `<style> 
        product-details {
        text-align: center;
        }
    </style>`
    // cant figure out how to get the css working in this but thats for later
})