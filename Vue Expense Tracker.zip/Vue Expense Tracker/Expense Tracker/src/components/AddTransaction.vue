<template>
    <h3>Add new transaction</h3>
      <form id="form" @submit.prevent="onSubmit">
        <div class="form-control">
          <label for="text">Transaction Name</label>
          <input type="text" id="text" placeholder="Enter text..." v-model="expenses" />
        </div>
        <div class="form-control">
          <label for="amount">
            Amount <br />
            (negative - expense, positive - income)
          </label>
          <input type="text" v-model="amount" id="amount" placeholder="Enter amount..." />
        </div>
        <button class="btn">Add transaction</button>
      </form>
</template>

<script setup>
import {ref} from 'vue'
import {useToast} from 'vue-toastification'

const toast = useToast()

const emit = defineEmits(['transactionSubmitted'])// to make custom events that we want to emit. Has an array of events with custom names

const expenses = ref('')
const amount = ref('')

  const onSubmit = () => {
    if(!expenses.value || !amount.value) {
      toast.error('Please use all fields')
      return
    }

    const transactionData = {
      expense: expenses.value,
      amount: parseFloat(amount.value)//takes in a string and pareses it as a float
    }

    emit('transactionSubmitted', transactionData)// emits the transaction data to the parent component when the parent calls the event

    expenses.value = ''
    amount.value = ''

  }
</script>