<template>
    <h2>Expense Tracker</h2>
</template>