<template>
    <h3>History</h3>
      <ul id="list" class="list">
        <li v-for="transaction in transactions" :key="transaction.id" :class="transaction.amount < 0 ? 'minus' : 'plus'"> <!--if amount < 0 make class=minus else class=plus-->
          {{transaction.text}} <span>${{ transaction.amount }}</span>
          <button class="delete-btn" @click="removeTransaction">x</button>
        </li>
        <!-- <li class="minus">
          Cash <span>-$400</span><button class="delete-btn">x</button>
        </li> 
        <li class="plus">
          Pay Day <span>$800</span><button class="delete-btn">x</button>
        </li> -->
      </ul> 
</template>

<script setup>
import { defineProps } from 'vue'

// setting up props like in the options 
const props = defineProps({
  transactions: {
    type: Array,
    required: true
  }
})

const emit = defineEmits(['transactionDeleted'])

const removeTransaction = () => {
  emit(transactionDeleted, id)
}
</script>