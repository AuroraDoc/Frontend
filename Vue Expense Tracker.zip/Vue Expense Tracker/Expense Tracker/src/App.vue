<template>
    <Header />
    <div class="container">
        <Balance :total="+total"/>
        <IncomeExpense :income="+income" :expenses="+expenses"/> <!--the + makes the value a number-->
        <TransactionList :transactions="transactions" @transactionDeleted="handledTransactionDeleted"/>
        <AddTransaction @transactionSubmitted="handleTransactionSubmit"/>
    </div>

</template>

<script setup>
import Header from './components/Header.vue'
import Balance from './components/Balance.vue'
import IncomeExpense from './components/IncomeExpense.vue'
import TransactionList from './components/TransactionList.vue'
import AddTransaction from './components/AddTransaction.vue'

import { useToast } from 'vue-toastification'
import { ref, computed, onMounted } from 'vue' // onMounted fires off right when the app mounts

const toast = useToast()

const transactions = ref([
        
      ])

onMounted(() =>{
    const savedTransactions = JSON.parse(localStorage.getItem('transactions'))

    if(savedTransactions) {
        transactions.value = savedTransactions
    }
})
// Explicit setup function. Both this and the uncommented one are using composition api
/*export default {
  setup() {
    const transactions = [
        { id: 1, text: 'Flower', amount: -19.99 },
        { id: 2, text: 'Paycheck', amount: 200 }
      ]
      return transactions}}*/

const total = computed(() => {
    return transactions.value.reduce((acc, transaction) => {
        return acc + transaction.amount// reduce is used to put a callback into the func. to then have an accumulator to add the next value to. Stores the previous vals
    }, 0) //0 is where the accumulator starts at
    //if you dont do .value you get an object rather than just the array 
})

//Get Income
const income = computed(() => {
    return transactions.value.filter((transaction) => transaction.amount > 0)// filter you pass in a callback to select only what you want from the array
    .reduce((acc, transaction) => {
        return acc + transaction.amount
    }, 0).toFixed(2)// only allows specified amount of places past decimal
    
})
//Get Expenses
const expenses = computed(() => {
    return transactions.value.filter((transaction) => transaction.amount < 0)
    .reduce((acc, transaction) => {
        return acc + transaction.amount
    }, 0).toFixed(2)
})
//add transaction

const handleTransactionSubmit = (transactionData) => {
    transactions.value.push({
        id: generateId(),
        text: transactionData.expense,
        amount: transactionData.amount
    })
    saveTransactionsToStorage()
    toast.success("Transaction Added!")
}

// Generate unique id
const generateId = () => {
    return transactions.value.length + 1
}

//Delete Transaction
const handledTransactionDeleted = () => {
    transactions.value.filter((transaction) !== transaction.id)// filter out the transactions that dont have that id

    saveTransactionsToStorage()
    toast.success("Transaction Deleted")
}

//Save to Local Storage
const saveTransactionsToStorage = () => {
    localStorage.setItem('transactions', JSON.stringify(transactions.value))
}

//Ideas to add: Date it was submitted, different accounts, Auth for multiple users
//Accounts: Thinking a json file that creates a new object for each account
</script>